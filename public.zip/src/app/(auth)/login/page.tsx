import React from "react";
import Login from "../../components/Login";

const page = () => {
  return (
    <div>
      <Login />
    </div>
  );
};

export default page;
